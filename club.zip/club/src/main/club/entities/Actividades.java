package entities;

public class Actividades {
    
    private int id;
    private String nombre;
    private String entrenador;
    private int dia;
    private int idActividad;
    
    
    
    public Actividades() {
    }



    public Actividades(String nombre, String entrenador, int dia, int idActividad) {
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.dia = dia;
        this.idActividad = idActividad;
    }



    public Actividades(int id, String nombre, String entrenador, int dia, int idActividad) {
        this.id = id;
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.dia = dia;
        this.idActividad = idActividad;
    }

    @Override
    public String toString() {
        return "Actividades [id=" + id + ", nombre=" + nombre + ", entrenador=" + entrenador + ", dia=" + dia
                + ", idActividad=" + idActividad + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(String entrenador) {
        this.entrenador = entrenador;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getIdActividad() {
        return idActividad;
    }

    public void setIdActividad(int idActividad) {
        this.idActividad = idActividad;
    }

    

}

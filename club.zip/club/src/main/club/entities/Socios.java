
public class Socios {

    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int idActividades;
    
    
    
    public Socios() {
    }


    public Socios(String nombre, String apellido, int edad, int idActividades) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.idActividades = idActividades;
    }


    public Socios(int id, String nombre, String apellido, int edad, int idActividades) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.idActividades = idActividades;
    }

    @Override
    public String toString() {
        return "Socios [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad
                + ", idActividades=" + idActividades + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getIdActividades() {
        return idActividades;
    }

    public void setIdActividades(int idActividades) {
        this.idActividades = idActividades;
    }

    

}

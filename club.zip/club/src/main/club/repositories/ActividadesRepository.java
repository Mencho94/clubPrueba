package club.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import club.connectors;
import club.entities.Actividades;
import club.enums.Dias;
import club.enums.Horarios;

public class ActividadesRepository {

    private Connection conn = Connector.getConnection();

    public void save(Actividades actividades) {
        if (actividades == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into actividades (nombre,entrenador,dia,horarios) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, curso.getNombre());
            ps.setString(2, curso.getEntrenador());
            ps.setString(3, curso.getDia().toString());
            ps.setString(4, curso.getHorarios().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                Actividades.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Actividades> getAll() {
        List<Actividades> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from actividades")) {
            while (rs.next()) {
                list.add(new Actividades(
                        rs.getInt("id"), // id
                        rs.getString("nombre"), // titulo
                        rs.getString("Entrenador"), // profesor
                        Dia.valueOf(rs.getString("dia")), // dia
                        Turno.valueOf(rs.getString("horarios")) // turno
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Actividades getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new Curso());
    }

    public List<Atividades>getLikeTitulo(String nombre){
        if(nombre==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(c->c.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                    .toList();      //JDK 16 o sup
    }


    


}

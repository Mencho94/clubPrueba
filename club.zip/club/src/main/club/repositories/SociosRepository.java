package club.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import club.connectors;
import club.entities;

public class SociosRepository {
    
    public class SociosRepository {
        private Connection conn = Connector.getConnection();
        
        public void save(Socios Socios) {
            if (Socios == null) return;
            try (PreparedStatement ps = conn.prepareStatement(
                    "insert into socios (nombre, apellido, edad, idActividad) values (?,?,?,?)",
                    PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, socios.getNombre());
                ps.setString(2, socios.getApellido());
                ps.setInt(3, socios.getEdad());
                ps.setInt(4, socios.getIdActividades());
                ps.execute();
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next())
                    socios.setId(rs.getInt(1));
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    
        public List<Socios> getAll() {
            List<Socios> list = new ArrayList();
            try (ResultSet rs = conn.createStatement().executeQuery("select * from socios")) {
                while (rs.next()) {
                    list.add(new Socios(
                            rs.getInt("id"),            // id
                            rs.getString("nombre"),     // nombre
                            rs.getString("apellido"),   // apellido
                            rs.getInt("edad"),          // edad
                            rs.getInt("idActividades")        // idActividades
                    ));
                }
            } catch (Exception e) {
                System.out.println(e);
            }
            return list;
        }
    
        public Socios getById(int id) {
            return getAll()
                    .stream()
                    .filter(a -> a.getId() == id)
                    .findFirst()
                    .orElse(new Socios());
        }
    
        public List<Socios>getLikeApellido(String apellido){
            if(apellido==null) return new ArrayList();
            return getAll()
                        .stream()
                        .filter(a->a.getSocios().toLowerCase().contains(apellido.toLowerCase()))
                        .toList();      //JDK 16 o sup
        }
    }

}

public enum Horarios {

    MAÑANA,
    TARDE,
    NOCHE
    
}

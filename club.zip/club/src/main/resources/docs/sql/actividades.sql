INSERT INTO actividades (nombre, entrenador, dia, horario) VALUES
    ('Futbol', 'Enzo Martinez', 'LUNES', 'MAÑANA'),
    ('Boxeo', 'Roman Romano', 'MARTES', 'TARDE'),
    ('Basquet', 'Leo Rodriguez', 'MIERCOLES', 'NOCHE'),
    ('Handbol', 'Lara Fernandez', 'JUEVES', 'TARDE'),
    ('Voley', 'Laura Fernández', 'VIERNES', 'MAÑANA');

-- nombre de las actividades que se realizan en el horario de la tarde
SELECT nombre
FROM actividades
WHERE horario = 'TARDE';
    